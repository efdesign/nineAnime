// content.js

window.addEventListener('load', (event) => {
    var style = document.createElement('style');
    style.type = 'text/css';
    // moves the porn iframe out of the view
    // some stuff is overridden, but moving out of the view works.
    style.innerHTML = `html > iframe:nth-child(4) {display:none !important ; zoom:0; transform:translateY(-200px)}`; // Inserisci qui il tuo stile CSS personalizzato
    document.head.appendChild(style);
});

